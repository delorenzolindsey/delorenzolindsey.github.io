package com.example.recipez;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import androidx.fragment.app.Fragment;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link dinnerFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class dinnerFragment extends Fragment {

    private recipesDB dbHelper;
    private GridView dinnerGrid;
    private ArrayList<recipe> recipeList;
    private GridAdapter adapter;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public dinnerFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment dinnerFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static dinnerFragment newInstance(String param1, String param2) {
        dinnerFragment fragment = new dinnerFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
        dbHelper = new recipesDB(getContext());
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_dinner, container, false);

        GridView dinnerGrid = view.findViewById(R.id.dinnerGrid);
        recipeList = new ArrayList<>();
        adapter = new GridAdapter(getContext(), R.layout.gridview_base, recipeList);
        dinnerGrid.setAdapter(adapter);

        // Call the method to fetch and display the recipes
        displayDinnerRecipes();

        return view;
    }


    private void displayDinnerRecipes() {
        recipeList.clear(); // Clear the list before adding new items
        Cursor cursor = null;

        try {
            // The key change is here: use a WHERE clause to filter the results
            String sqlQuery = "SELECT * FROM " + recipesDB.TABLE_RECIPES + " WHERE " + recipesDB.COLUMN_CATEGORY + " = 'dinner'";
            cursor = dbHelper.getData(sqlQuery);

            if (cursor != null && cursor.moveToFirst()) {
                // Get column indices
                int idColIndex = cursor.getColumnIndex(recipesDB.COLUMN_ID);
                int nameColIndex = cursor.getColumnIndex(recipesDB.COLUMN_NAME);
                int categoryColIndex = cursor.getColumnIndex(recipesDB.COLUMN_CATEGORY);
                int ingredientsColIndex = cursor.getColumnIndex(recipesDB.COLUMN_INGREDIENTS);
                int instructionsColIndex = cursor.getColumnIndex(recipesDB.COLUMN_INSTRUCTIONS);


                if (idColIndex == -1 || nameColIndex == -1 || categoryColIndex == -1 ||
                        ingredientsColIndex == -1 || instructionsColIndex == -1 ) {
                    Toast.makeText(getContext(), "One or more columns not found in database.", Toast.LENGTH_LONG).show();
                    return;
                }

                // Loop through the cursor and create recipe objects
                do {
                    int id = cursor.getInt(idColIndex);
                    String name = cursor.getString(nameColIndex);
                    String category = cursor.getString(categoryColIndex);
                    String ingredients = cursor.getString(ingredientsColIndex);
                    String instructions = cursor.getString(instructionsColIndex);


                    recipeList.add(new recipe(id, name, category, ingredients, instructions));
                } while (cursor.moveToNext());
            } else {
                // Display a message if no breakfast recipes were found
                Toast.makeText(getContext(), "No dinner recipes found.", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Toast.makeText(getContext(), "Error loading recipes: " + e.getMessage(), Toast.LENGTH_LONG).show();
            e.printStackTrace();
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }

        // Notify the adapter to update the GridView
        adapter.notifyDataSetChanged();
    }

    @Override
    public void onResume() {
        super.onResume();
        // Reload data whenever the fragment becomes visible again
        displayDinnerRecipes();
    }

}