package com.example.recipez;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;


public class GridAdapter extends BaseAdapter {
    private Context context;
    private  int layout;
    private ArrayList<recipe> recipeList;

    public GridAdapter(Context context, int layout, ArrayList<recipe> recipeList){
        this.context = context;
        this.layout = layout;
        this.recipeList = recipeList;
    }

    @Override
    public int getCount(){
        return recipeList.size();
    }

    @Override
    public Object getItem(int position) {
        return recipeList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    private class ViewHolder {
        TextView txtName;
        TextView txtCategory;
        TextView txtIngredients;
        TextView txtInstructions;
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {
        View row = view;
        ViewHolder holder = new ViewHolder();

        if (row == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            row = inflater.inflate(layout, null);

            holder.txtName = row.findViewById(R.id.item_name);
            holder.txtCategory = row.findViewById(R.id.item_category);
            holder.txtIngredients = row.findViewById(R.id.item_ingredients);
            holder.txtInstructions = row.findViewById(R.id.item_instructions);
            row.setTag(holder);
        } else {
            holder = (ViewHolder) row.getTag();
        }

        recipe recipe = recipeList.get(position);

        holder.txtName.setText(recipe.getName());
        holder.txtCategory.setText(recipe.getCategory());
        holder.txtIngredients.setText(recipe.getIngredients());
        holder.txtInstructions.setText(recipe.getInstructions());

        return row;
    }

    public void updateData(ArrayList<recipe> newRecipeArrayList) {
        this.recipeList.clear();
        this.recipeList.addAll(newRecipeArrayList);
        notifyDataSetChanged();
    }

}
