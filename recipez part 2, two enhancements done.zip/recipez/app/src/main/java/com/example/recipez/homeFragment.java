package com.example.recipez;


import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.database.Cursor;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.Toast;
import android.widget.SearchView;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 * Use the {@link homeFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class homeFragment extends Fragment {
    private recipesDB dbHelper;
    //private ArrayList<recipe> recipeList;
    private GridAdapter adapter;

    //declare UI elements for XML
    private EditText nameEditText;
    private EditText categoryEditText;
    private EditText ingredientsEditText;
    private EditText instructionsEditText;
    private Button addButton;
    private SearchView searchView;
    private GridView homeGridView;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public homeFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment HomeFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static homeFragment newInstance(String param1, String param2) {
        homeFragment fragment = new homeFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
        //Initialize database help
        dbHelper = new recipesDB(getContext());
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        //Initialize UI elements
        nameEditText = view.findViewById(R.id.NameEditText);
        categoryEditText = view.findViewById(R.id.CategoryEditText);
        ingredientsEditText = view.findViewById(R.id.IngredientsEditText);
        instructionsEditText = view.findViewById(R.id.InstructionsEditText);
        addButton = view.findViewById(R.id.addButton);
        searchView = view.findViewById(R.id.searchView);



        //Initialize grid elements and adapter
        GridView homeGridView = view.findViewById(R.id.homeGridView);
        adapter = new GridAdapter(getContext(), R.layout.gridview_base, new ArrayList<recipe>());
        homeGridView.setAdapter(adapter);

        // Set OnClickListener for the Add New button
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addNewRecipe();
            }
        });

        // Set OnQueryTextListener for the SearchView
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                loadRecipes(query); // Load recipes based on the submitted query
                searchView.clearFocus();
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                // for live search:
                loadRecipes(newText);
                return false;
            }
        });

        loadRecipes(null);
        return view;
    }

    private void addNewRecipe() {
        String name = nameEditText.getText().toString().trim();
        String category = categoryEditText.getText().toString().trim();
        String ingredients = ingredientsEditText.getText().toString().trim();
        String instructions = instructionsEditText.getText().toString().trim();

        // Basic validation: ensure recipe name not empty
        if (name.isEmpty()) {
            Toast.makeText(getContext(), "Recipe name cannot be empty!", Toast.LENGTH_SHORT).show();
            return; // Stop the method if validation fails
        }



        try {
            dbHelper.insertData(name, category, ingredients, instructions);
            Toast.makeText(getContext(), "Recipe added successfully!", Toast.LENGTH_SHORT).show();

            // Clear the input fields after successful insertion
            nameEditText.setText("");
            categoryEditText.setText("");
            ingredientsEditText.setText("");
            instructionsEditText.setText("");

            // Reload the recipes to update the GridView
            loadRecipes(searchView.getQuery().toString());

        } catch (Exception e) {
            Toast.makeText(getContext(), "Error adding recipe: " + e.getMessage(), Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }

    private void loadRecipes(String query) {
        //recipeList.clear(); // Clear existing data to avoid duplicates

        ArrayList<recipe> loadedRecipes = new ArrayList<>();

        String queryString;
        String[] selectionArgs = null;


        if (query != null && !query.isEmpty()) {
            // If a query is provided, build a WHERE clause to search across multiple columns
            queryString = "SELECT * FROM " + recipesDB.TABLE_RECIPES +
                    " WHERE " + recipesDB.COLUMN_NAME + " LIKE ?" +
                    " OR " + recipesDB.COLUMN_CATEGORY + " LIKE ?" +
                    " OR " + recipesDB.COLUMN_INGREDIENTS + " LIKE ?" +
                    " OR " + recipesDB.COLUMN_INSTRUCTIONS + " LIKE ?";
            selectionArgs = new String[]{"%" + query + "%", "%" + query + "%", "%" + query + "%", "%" + query + "%"};
        } else {
            // If no query, select all recipes
            queryString = "SELECT * FROM " + recipesDB.TABLE_RECIPES;
        }

        Cursor cursor = null;
        try {
            if (selectionArgs != null) {
                // Call getData(String query, String[] selectionArgs) for parameterized queries
                cursor = dbHelper.getData(queryString, selectionArgs);
            } else {
                // Call getData(String sql) for simple queries without parameters
                cursor = dbHelper.getData(queryString);
            }
            if (cursor != null && cursor.moveToFirst()) {
                int idColIndex = cursor.getColumnIndex(recipesDB.COLUMN_ID);
                int nameColIndex = cursor.getColumnIndex(recipesDB.COLUMN_NAME);
                int categoryColIndex = cursor.getColumnIndex(recipesDB.COLUMN_CATEGORY);
                int ingredientsColIndex = cursor.getColumnIndex(recipesDB.COLUMN_INGREDIENTS);
                int instructionsColIndex = cursor.getColumnIndex(recipesDB.COLUMN_INSTRUCTIONS);

                if (idColIndex == -1 || nameColIndex == -1 || categoryColIndex == -1 ||
                        ingredientsColIndex == -1 || instructionsColIndex == -1 ) {
                    Toast.makeText(getContext(), "One or more columns not found", Toast.LENGTH_LONG).show();
                    return; // Exit if columns are missing
                }

                do {
                    int _id = cursor.getInt(idColIndex);
                    String name = cursor.getString(nameColIndex);
                    String category = cursor.getString(categoryColIndex);
                    String ingredients = cursor.getString(ingredientsColIndex);
                    String instructions = cursor.getString(instructionsColIndex);


                    loadedRecipes.add(new recipe(_id, name, category, ingredients, instructions));
                } while (cursor.moveToNext());
            } else {
                Toast.makeText(getContext(), "No recipes found.", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Toast.makeText(getContext(), "Error loading recipes: " + e.getMessage(), Toast.LENGTH_LONG).show();
            e.printStackTrace();
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }

        // Notify the adapter that the data has changed
        adapter.updateData(loadedRecipes);
    }

    @Override
    public void onResume() {
        super.onResume();
        // Reload data whenever the fragment becomes visible again
        loadRecipes(searchView.getQuery().toString());
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (dbHelper != null) {
            dbHelper.close();
        }
    }
}